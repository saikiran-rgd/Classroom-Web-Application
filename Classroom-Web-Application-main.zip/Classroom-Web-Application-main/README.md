# Classroom-Web-Application
This is a Classroom web Application
This web application enables educational institutions to manage courses, assignments, and student performance effectively. Teachers can create courses, upload assignments, grade submissions, and facilitate discussions, while students can enroll in courses, submit assignments, and view their grades. The app also features a simple discussion forum where students and teachers can interact. Built with JSP, Servlets, and Oracle Database, it provides a user-friendly interface for both teachers and students, with easy-to-navigate dashboards and real-time feedback.

Key Features:
Course management and enrollment
Assignment submission and grading
View grades and feedback
Participate in course discussions
Fully customizable and adaptable to institutional needs
